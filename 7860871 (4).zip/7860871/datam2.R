#csv dosyalarını okumak için read fonksiyonu kullanma.
datam2 <- read_csv("Youth_Tobacco_Survey__YTS__Data (1).csv")

# dosyanın doğru bir şekilde okunduğunu ve veri çerçevesine 
#doğru bir şekilde aktarıldığını göstermek için read_delim kullanma
datam2=read_delim("Youth_Tobacco_Survey__YTS__Data (1).csv")

#nesnenin boyutunu döndürmek için dim fonksiyonu kullanma
dim(problems(datam2))

# eri çerçevesinin özelliklerini döndürme
spec(datam2)

# veri setinin okunması sırasında ortaya çıkan hataların yönetimi için
#stop_for_problems fonksiyonunu kullanma
stop_for_problems(datam2)

# veri setinin ilk üç satırını görmek için library(readr) paketinde
#head fonksiyonunu kullanma

library(readr)
head(datam2, 3)

# class fonksiyonu ile nesnenin sınıfını gösterme
class(datam2)

# nrow ile satır sayısını görme
nrow(datam2)

#ncol ile sütün sayısını görme
ncol(datam2)

#veri çerçevesinin boyutlarını döndürme
dim(datam2)

# bir veri çerçevesinin sütun adlarını göstermek için colnames kullanma
colnames(datam2)

# çalışma dizini görtermek için getwd fonksiyonu kullanma
getwd()
setwd("/cloud/project")

# dizinde bulunan dosyaları veya alt dizinleri listeleyen dir fonksiyonu
dir("./") 
dir("..")
#

#help ile fonksiyonlar hakkında bilgi edinme
help("dir")
#önce soru işareri sonra fonksiyan adı yazılarak da yapılır.
?dir

#veri manipülasyonu için dplyr fonksiyonu kullanma
install.packages("dplyr")
library(dplyr)
#verideki year ifadesini Year olarak güncelleme

datam2 = rename(datam, year = YEAR)
names(datam2)

#dışa veri aktarmak için write_delim fonksiyonu kullanma
datam2 = rename(datam2, Year = year)
write_csv(datam2, path = "Youth_Tobacco_Survey__YTS__Data (1).csv")

#write_rds() işlevi, veri nesnesini bir RDS dosyasına 
#yazarken veri kaybı olmadan nesnenin tamamen korunması için kullanılır.
write_rds(datam2, "year")

#datam2 = read_rds(path = "Youth_Tobacco_Survey__YTS__Data (1).csv.rds)
identical(dat, dat2) # test if they are the same

# read csv ile veriyi okuma

#datam2 = read.csv("Youth_Tobacco_Survey__YTS__Data (1).csv")
head(datam2)


